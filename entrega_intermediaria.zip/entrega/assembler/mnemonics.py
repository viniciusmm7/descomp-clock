mnemonics = {
    "NOP":  0,
    "LDA":  1,
    "ADD":  2,
    "SUB":  3,
    "LDI":  4,
    "STA":  5,
    "JMP":  6,
    "JEQ":  7,
    "CEQ":  8,
    "JSR":  9,
    "RET":  10,
    "AND":  11,
}